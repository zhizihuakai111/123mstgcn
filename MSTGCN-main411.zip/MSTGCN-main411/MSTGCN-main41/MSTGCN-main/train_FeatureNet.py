import os
import numpy as np
import argparse
import shutil
import gc

import keras
import tensorflow as tf
import keras.backend.tensorflow_backend as KTF

from model.FeatureNet import build_FeatureNet
from model.DataGenerator import kFoldGenerator
from model.Utils import *
# 总的来说，这段代码用于训练深度学习模型，其中包括以下关键步骤：配置环境、读取数据、构建模型、进行交叉验证的训练，并保存模型和学到的特征。这些操作可以用于训练具体任务的深度学习模型，如分类或回归等。
print(128 * '#')
print('Start to train FeatureNet.')

# # 1. Get configuration

# ## 1.1. Read .config file

# command line parameters -c -g
parser = argparse.ArgumentParser()
parser.add_argument("-c", type = str, help = "configuration file", required = True)
parser.add_argument("-g", type = str, help = "GPU number to use, set '-1' to use CPU", required = True)
args = parser.parse_args()
Path, cfgFeature, _, _ = ReadConfig(args.c)

# set GPU number or use CPU only
os.environ["CUDA_VISIBLE_DEVICES"] = args.g
if args.g != "-1":
    config = tf.ConfigProto()  
    config.gpu_options.allow_growth=True
    sess = tf.Session(config=config)
    KTF.set_session(sess)
    print("Use GPU #"+args.g)
else:
    print("Use CPU only")

# ## 1.2. Analytic parameters

# [train] parameters ('_f' means FeatureNet)
channels   = int(cfgFeature["channels"])
fold       = int(cfgFeature["fold"])
num_epochs_f = int(cfgFeature["epoch_f"])
batch_size_f = int(cfgFeature["batch_size_f"])
optimizer_f  = cfgFeature["optimizer_f"]
learn_rate_f = float(cfgFeature["learn_rate_f"])


# ## 1.3. Parameter check and enable

# Create save pathand copy .config to it
if not os.path.exists(Path['Save']):
    os.makedirs(Path['Save'])
shutil.copyfile(args.c, Path['Save']+"last.config")


# # 2. Read data and process data

# ## 2.1. Read data
# Each fold corresponds to one subject's data (ISRUC-S3 dataset)
ReadList = np.load(Path['data'], allow_pickle=True)
Fold_Num   = ReadList['Fold_len']    # Num of samples of each fold
Fold_Data  = ReadList['Fold_data']   # Data of each fold
Fold_Label = ReadList['Fold_label']  # Labels of each fold

print("Read data successfully")
print('Number of samples: ',np.sum(Fold_Num))

# ## 2.2. Build kFoldGenerator or DominGenerator
DataGenerator = kFoldGenerator(Fold_Data, Fold_Label)


# # 3. Model training (cross validation)

# k-fold cross validation
all_scores = []
for i in range(fold):
    print(128*'_')
    print('Fold #', i)

    # Instantiation optimizer
    opt_f = Instantiation_optim(optimizer_f, learn_rate_f) # optimizer of FeatureNet
    
    # get i th-fold data
    train_data,train_targets,val_data,val_targets = DataGenerator.getFold(i)
    
    ## build FeatureNet & train
    featureNet, featureNet_p = build_FeatureNet(opt_f, channels) # '_p' model is without the softmax layer
    history_fea = featureNet.fit(
        x = train_data,
        y = train_targets,
        epochs = num_epochs_f,
        batch_size = batch_size_f,
        shuffle = True,
        validation_data = (val_data, val_targets),
        verbose = 2,
        callbacks=[keras.callbacks.ModelCheckpoint(Path['Save']+'FeatureNet_Best_'+str(i)+'.h5', 
                                                   monitor='val_acc', 
                                                   verbose=0, 
                                                   save_best_only=True, 
                                                   save_weights_only=False, 
                                                   mode='auto', 
                                                   period=1 )])
    # Save training information
    if i==0:
        fit_loss = np.array(history_fea.history['loss'])*Fold_Num[i]
        fit_acc = np.array(history_fea.history['acc'])*Fold_Num[i]
        fit_val_loss = np.array(history_fea.history['val_loss'])*Fold_Num[i]
        fit_val_acc = np.array(history_fea.history['val_acc'])*Fold_Num[i]
    else:
        fit_loss = fit_loss+np.array(history_fea.history['loss'])*Fold_Num[i]
        fit_acc = fit_acc+np.array(history_fea.history['acc'])*Fold_Num[i]
        fit_val_loss = fit_val_loss+np.array(history_fea.history['val_loss'])*Fold_Num[i]
        fit_val_acc = fit_val_acc+np.array(history_fea.history['val_acc'])*Fold_Num[i]

    # load the weights of best performance
    featureNet.load_weights(Path['Save']+'FeatureNet_Best_'+str(i)+'.h5')
    
    # get and save the learned feature
    train_feature = featureNet_p.predict(train_data)
    val_feature = featureNet_p.predict(val_data)
    print('Save feature of Fold #' + str(i) + ' to' + Path['Save']+'Feature_'+str(i) + '.npz')
    np.savez(Path['Save']+'Feature_'+str(i)+'.npz', 
        train_feature = train_feature,
        val_feature = val_feature,
        train_targets = train_targets,
        val_targets = val_targets
    )
    
    saveFile = open(Path['Save'] + "Result_FeatureNet.txt", 'a+')
    print('Fold #'+str(i), file=saveFile)
    print(history_fea.history, file=saveFile)
    saveFile.close()

    # Fold finish
    keras.backend.clear_session()
    del featureNet, featureNet_p, train_data, train_targets, val_data, val_targets, train_feature, val_feature
    gc.collect()

print(128 * '_')

print('End of training FeatureNet.')
print(128 * '#')
# 导入库：代码开始通过导入必要的Python库，包括NumPy、Argparse、Shutil等，以及深度学习框架Keras和TensorFlow的相关模块。
#
# 读取配置文件：通过命令行参数解析（argparse），从配置文件中读取模型训练的相关参数和路径。这些参数包括模型超参数、数据路径、GPU设置等。
#
# GPU设置：根据命令行参数中的GPU编号，配置是否使用GPU或CPU进行训练，并设置相应的GPU设备。如果使用GPU，还配置了GPU内存动态分配。
#
# 参数解析：从配置文件中解析和提取模型训练所需的各项参数，包括通道数、折数、训练轮数、批次大小、优化器、学习率等。
#
# 创建保存路径：如果指定的保存路径不存在，则创建该路径，并将配置文件复制到该路径下以备记录。
#
# 读取和处理数据：从指定路径中读取数据，包括数据长度、数据内容、标签等。这些数据被用于后续的模型训练。
#
# 构建数据生成器：通过kFoldGenerator类构建数据生成器，用于在交叉验证过程中生成训练和验证数据集。
#
# 模型训练（交叉验证）：进行k折交叉验证的模型训练。在每个交叉验证迭代中，以下操作都会被执行：
#
# 实例化模型的优化器。
# 获取当前交叉验证折的训练和验证数据。
# 构建FeatureNet模型（以及没有softmax层的版本）并进行训练。
# 保存每个折中性能最佳的模型权重。
# 获取并保存学到的特征。
# 记录训练过程中的损失和准确度信息。
# 清除模型和释放内存资源。
# 训练结束：所有的交叉验证折完成后，代码会清理会话、删除模型以及释放内存资源。
#