import numpy as np
import matplotlib.pyplot as plt

# 读取npy文件
data = np.load('E:\\suanfa\\fenlei_yuce\\MSTGCN-main41\\MSTGCN-main\\data\\ISRUC_S3\\DistanceMatrix.npy')

# 显示数组内容
print(data)

# 可视化数组（示例为二维数组）
plt.imshow(data, cmap='viridis')  # 使用合适的colormap
plt.show()