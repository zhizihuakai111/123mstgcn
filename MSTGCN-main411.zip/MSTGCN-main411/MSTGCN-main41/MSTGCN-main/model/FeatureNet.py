import tensorflow as tf
import keras
from keras.models import Model
from keras.layers import Input, Conv1D, Dense, Dropout, MaxPool1D, Activation
from keras.layers import Flatten, Reshape, TimeDistributed, BatchNormalization

'''
A Feature Extractor Network
'''
#总的来说，这段代码定义了一个用于特征提取和分类的深度学习模型，模型包括两个分支，分别用于捕捉不同尺度的特征。
#模型可以用于处理1D信号数据，例如生物特征信号，并具有用于分类和特征提取的两个版本。模型的构建和编译都采用了Keras框架的高级API。
def build_FeatureNet(opt, channels=8, time_second=3, freq=10):
    activation = tf.nn.relu
    padding = 'same'

    ######### Input ########
    input_signal = Input(shape=(time_second * freq,1), name='input_signal')

    ######### CNNs with small filter size at the first layer #########
    cnn0 = Conv1D(kernel_size=8,
                  filters=32,
                  strides=1,
                  kernel_regularizer=keras.regularizers.l2(0.001))
    s = cnn0(input_signal)
    s = BatchNormalization()(s)
    s = Activation(activation=activation)(s)
    cnn1 = MaxPool1D(pool_size=2, strides=2)
    s = cnn1(s)
    cnn2 = Dropout(0.5)
    s = cnn2(s)
    cnn3 = Conv1D(kernel_size=8, filters=64, strides=1, padding=padding)
    s = cnn3(s)
    s = BatchNormalization()(s)
    s = Activation(activation=activation)(s)
    cnn4 = Conv1D(kernel_size=8, filters=64, strides=1, padding=padding)
    s = cnn4(s)
    s = BatchNormalization()(s)
    s = Activation(activation=activation)(s)
    cnn5 = Conv1D(kernel_size=8, filters=64, strides=1, padding=padding)
    s = cnn5(s)
    s = BatchNormalization()(s)
    s = Activation(activation=activation)(s)
    cnn6 = MaxPool1D(pool_size=8, strides=8)
    s = cnn6(s)
    cnn7 = Reshape((int(s.shape[1]) * int(s.shape[2]), ))  # Flatten
    s = cnn7(s)

    ######### CNNs with large filter size at the first layer #########
    cnn8 = Conv1D(kernel_size=10,
                  filters=64,
                  strides=1,
                  kernel_regularizer=keras.regularizers.l2(0.001))
    l = cnn8(input_signal)
    l = BatchNormalization()(l)
    l = Activation(activation=activation)(l)
    cnn9 = MaxPool1D(pool_size=2, strides=2)
    l = cnn9(l)
    cnn10 = Dropout(0.5)
    l = cnn10(l)
    cnn11 = Conv1D(kernel_size=6, filters=64, strides=1, padding=padding)
    l = cnn11(l)
    l = BatchNormalization()(l)
    l = Activation(activation=activation)(l)
    cnn12 = Conv1D(kernel_size=6, filters=64, strides=1, padding=padding)
    l = cnn12(l)
    l = BatchNormalization()(l)
    l = Activation(activation=activation)(l)
    cnn13 = Conv1D(kernel_size=6, filters=64, strides=1, padding=padding)
    l = cnn13(l)
    l = BatchNormalization()(l)
    l = Activation(activation=activation)(l)
    cnn14 = MaxPool1D(pool_size=4, strides=4)
    l = cnn14(l)
    cnn15 = Reshape((int(l.shape[1]) * int(l.shape[2]), ))
    l = cnn15(l)

    feature = keras.layers.concatenate([s, l])

    fea_part = Model(input_signal, feature)

    ##################################################

    input = Input(shape=(channels, time_second * freq), name='input_signal')
    reshape = Reshape((channels, time_second * freq, 1))  # Flatten
    input_re = reshape(input)
    fea_all = TimeDistributed(fea_part)(input_re)

    merged = Flatten()(fea_all)
    merged = Dropout(0.5)(merged)
    merged = Dense(64)(merged)
    merged = Dense(3)(merged)

    fea_softmax = Activation(activation='softmax')(merged)

    # FeatureNet with softmax
    fea_model = Model(input, fea_softmax)
    fea_model.compile(optimizer=opt,
                      loss='categorical_crossentropy',
                      metrics=['acc'])

    # FeatureNet without softmax
    pre_model = Model(input, fea_all)
    pre_model.compile(optimizer=opt,
                      loss='categorical_crossentropy',
                      metrics=['acc'])

    return fea_model, pre_model

# 导入库和模块：
#
# 代码开始导入了必要的深度学习库，包括TensorFlow和Keras。
# 从Keras中导入了模型构建相关的类和函数，如Model、Input、Conv1D等。
# 模型构建：
#
# build_FeatureNet函数用于构建FeatureNet模型和一个不包含Softmax层的预测模型。
# 模型的输入是1D信号，通常用于处理时域信号数据（例如，生物特征信号）。
# 代码定义了两个分支的卷积神经网络（CNN）：
# 第一个分支（标记为s）包括多个卷积层、池化层和规范化层。这个分支用较小的卷积核来捕捉信号中的细节特征。
# 第二个分支（标记为l）与第一个分支类似，但使用了较大的卷积核，以捕捉信号中的更大尺度特征。
# 两个分支的输出特征被连接起来（concatenate），形成最终的特征表示。
# 随后，特征表示经过一些全连接层（Dense）和激活函数，最终输出包含3个类别的预测结果（用Softmax激活函数）。
# 模型包括两个版本：一个用于分类任务（fea_model），另一个用于提取特征表示而不进行分类（pre_model）。
# 模型编译：
#
# fea_model和pre_model都被编译，分别使用交叉熵损失函数和准确率指标作为优化目标。
# 优化器、损失函数和性能指标都可以在函数参数中指定。